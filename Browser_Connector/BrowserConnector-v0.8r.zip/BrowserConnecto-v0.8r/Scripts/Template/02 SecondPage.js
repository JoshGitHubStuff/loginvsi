﻿//Path=/path/to/second-page
console.log("Running script for 'second page'");

async function Run() {
    alert("We are in the second page");
}

Run();