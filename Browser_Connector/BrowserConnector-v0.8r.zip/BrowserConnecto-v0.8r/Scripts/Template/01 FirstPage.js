﻿//Path=/path/to/first-page
console.log("Running script for 'first page'");

async function Run() {
    alert("We are in the first page");
}

Run();


