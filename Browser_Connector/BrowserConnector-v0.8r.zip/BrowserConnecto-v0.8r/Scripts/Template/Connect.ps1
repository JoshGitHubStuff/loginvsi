﻿
param([String]$connectionFile="") 

Write-Host("Starting connection for file '$connectionFile'");

