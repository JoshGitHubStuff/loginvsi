﻿param(
	[String]$user="",
	[String]$resource="",
	[String]$connectionFile=""
)
[String]$dir = Get-Location
$assemblies=(
	"System",
    [system.io.path]::combine($dir, "Interop.UIAutomationClient.dll"),
    [system.io.path]::combine($dir, "FlaUI.Core.dll"),
    [system.io.path]::combine($dir,"FlaUI.UIA3.dll"),
    "PresentationCore",
    "PresentationFramework",
    "System.Core",
    "System.IO.Compression",
    "System.Management",
    "System.Windows.Forms",
    "WindowsBase",
    "Accessibility"
)
$password = Read-Host "gimmy the password"

$sourceFile = [system.io.path]::combine($dir, "LocalClientLogin.cs")
Write-Host("Loading client automation logic from $sourceFile")

Write-Host("Getting list of currently running connection windows")
$source =[system.io.file]::readalltext($sourceFile);
Import-Module ".\\FlaUI.UIA3.dll"
Add-Type -ReferencedAssemblies $assemblies -TypeDefinition $source -Language CSharp

$runningConnections = [RemotingClientAutomation.Runner]::GetRunningConnections($resource)

Write-Host("Starting connection from file '$connectionFile' for user '$user'");
Start-Process -FilePath "C:\\Program Files\\Remote Desktop\\msrdc.exe" -ArgumentList "`"$connectionFile`" /u:$user"
#Start-Process $connectionFile

Start-Sleep -Seconds 1

Write-Host("Running client automation logic")

$result = [RemotingClientAutomation.Runner]::Run($user, $password, $resource, $runningConnections)

Write-Host("Done running client automation logic")

if ($result) {
    Write-Host("The connection was established")
    Exit(0)
} else {
    Write-Error("The connector returned with an error")
    Exit(-1)
}
