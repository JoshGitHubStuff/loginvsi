﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Conditions;
using FlaUI.Core.Definitions;
using FlaUI.Core.WindowsAPI;
using FlaUI.UIA3;
using FlaUI.UIA3.Converters;
using FlaUI.UIA3.Identifiers;
using System.Runtime.InteropServices;

namespace RemotingClientAutomation
{
    public static class Runner
    {
        public static IntPtr[] GetRunningConnections(string resourceName)
        {
            return GetConnectorWindowHandles(resourceName);
        }

        public static bool Run(string user, string password, string resourceName, IntPtr[] existingWindowHandles)
        {
            Console.WriteLine("Checking for additional authentication interaction for user " + user);
            Thread.Sleep(1000);

            using (var automation = new UIA3Automation())
            {
                var stopwatch = Stopwatch.StartNew();
                var credsHaveBeenFilled = false;
                var authenticated = false;
                while (stopwatch.Elapsed.TotalMinutes < 3)
                {
                    Console.WriteLine("Searching for new connection window");
                    var connectionWindowHandles = GetConnectorWindowHandles(resourceName);
                    if (connectionWindowHandles.Any(c => !existingWindowHandles.Contains(c)))
                    {
                        Console.WriteLine("Found new connection window!");
                        return true;
                    }

                    var topLevelWindows = GetTopLevelWindows();
                    foreach (var topLevelWindow in topLevelWindows)
                    {
                        Console.WriteLine(topLevelWindow.Class + " | " + topLevelWindow.Title);
                        if (IsConnectionErrorWindow(automation, topLevelWindow))
                            return false;

                        if (topLevelWindow.Title == "Windows Security")
                        {
                            if (credsHaveBeenFilled)
                            {
                                Console.WriteLine("Credentials have been filled already.");
                                continue;
                            }

                            credsHaveBeenFilled = FillWinCredWindow(automation, topLevelWindow, password);
                            break;
                        }

                        if (!IsAuthenticationWindow(topLevelWindow))
                            continue;

                        if (authenticated)
                        {
                            Console.WriteLine("We were already authenticated, ignoring other candidate authentication window");
                            continue;
                        }
                        if (FillAuthentication(automation, topLevelWindow, user, password))
                        {
                            authenticated = true;
                            break;
                        }
                    }
                    Thread.Sleep(1000);
                }

                Console.Error.WriteLine("The connector timed out");
                return false;
            }
        }

        private static bool FillAuthentication(UIA3Automation automation, TopLevelWindow window, string user, string password)
        {
            var child = automation.FromHandle(window.Handle);
            var stopwatch = Stopwatch.StartNew();
            var clickedUseAnotherAccount = ClickUseAnotherAccount(child);
            if (clickedUseAnotherAccount)
            {
                Thread.Sleep(1000);
            }

            var result = FindEmailEdit(child);

            if (clickedUseAnotherAccount)
            {
                while (result == null && stopwatch.Elapsed.TotalSeconds < 30)
                {
                    result = FindEmailEdit(child);
                }
            }

            if (result == null)
            {
                Console.WriteLine("EMail edit was not found");
                return false;
            }

            Console.WriteLine("Filling user field");
            result.AsTextBox().Text = user;
            ClickNext(child);

            Thread.Sleep(1000);
            stopwatch.Restart();
            result = FindPasswordEdit(child, user);
            while (result == null && stopwatch.Elapsed.TotalSeconds < 30)
            {
                Console.WriteLine("Password field is not yet available");
                result = FindPasswordEdit(child, user);
                Thread.Sleep(1000);
            }
            if (result == null)
            {
                Console.WriteLine("Password edit was not found");
                return false;
            }

            Console.WriteLine("Filling password field");
            result.AsTextBox().Text = password;
            return ClickSignIn(child);
        }

        private static IntPtr[] GetConnectorWindowHandles(string resourceName)
        {
            var handles = new List<IntPtr>();

            using (var automation = new UIA3Automation())
            {
                var lpszClass = "TscShellContainerClass";
                var handle = User32.FindWindowEx(IntPtr.Zero, IntPtr.Zero, lpszClass, null);
                while (handle != IntPtr.Zero)
                {
                    var window = automation.FromHandle(handle);
                    if (window.ClassName == lpszClass && window.AsWindow().Title.Contains(resourceName))
                    {
                        Console.WriteLine(window.ClassName);
                        handles.Add(handle);
                    }
                    handle = User32.FindWindowEx(IntPtr.Zero, handle, lpszClass, null);
                }
            }
            Console.WriteLine("Number of handles found: " + handles.Count);

            return handles.ToArray();
        }

        //
        /// <summary>
        /// Fill wincred window if it appears
        /// </summary>
        /// <param name="child"></param>
        /// <param name="window"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <param name="automation"></param>
        /// <returns>true if the error window appeared, false otherwise</returns>
        private static bool FillWinCredWindow(UIA3Automation automation, TopLevelWindow window, string password)
        {
            Console.WriteLine("Processing WinCredWindow");
            var child = automation.FromHandle(window.Handle);

            var passwordCondition = new AndCondition(
                child.ConditionFactory.ByControlType(ControlType.Edit),
                child.ConditionFactory.ByName("Password"));

            var passwordEdit = child.FindFirstDescendant(passwordCondition).AsTextBox();
            if (passwordEdit == null)
            {
                Console.WriteLine("Password field was not found in win-cred window");
                return false;
            }

            passwordEdit.Text = password;

            var checkBox = child.FindFirstDescendant(
                child.ConditionFactory.ByControlType(ControlType.CheckBox)).AsCheckBox();
            if (checkBox == null)
            {
                Console.WriteLine("Remember me checkbox was not found in win-cred window.");
            }
            else
            {
                checkBox.IsChecked = true;
            }

            var loginButtonCondition = new AndCondition(
                child.ConditionFactory.ByControlType(ControlType.Button),
                child.ConditionFactory.ByName("OK"));
            child.SetForeground();
            var loginButton = child.FindFirstChild(loginButtonCondition);
            if (loginButton == null)
            {
                Console.WriteLine("Login button was not found in win-cred window");
                return false;
            }

            loginButton.Click(false);

            return true;
        }

        /// <summary>
        /// If an error window has appeared, we close it and return true here
        /// The connector must exit with an error here
        /// The error is written to stderr by this method
        /// </summary>
        /// <param name="automation"></param>
        /// <param name="window"></param>
        /// <returns>true if the error window appeared, false otherwise</returns>
        private static bool IsConnectionErrorWindow(UIA3Automation automation, TopLevelWindow window)
        {
            if (window.Title != "Remote Desktop")
                return false;

            var processName = ProcessNameFromWindowHandle(window.Handle);
            if (!processName.Equals("msrdc"))
            {
                return false;
            }
            Console.WriteLine("Found candidate for connection error (title|class) " + window.Title + " | " + window.Class);
            var windowAutomationElement = automation.FromHandle(window.Handle);
            var parent = windowAutomationElement.Parent.AsWindow();

            var errorIcon = windowAutomationElement.FindFirstDescendant(
                    automation.ConditionFactory.ByName("MainInstructionIcon"));
            if (errorIcon != null)
            {
                var text = windowAutomationElement.FindFirstChild(
                    automation.ConditionFactory.ByControlType(ControlType.Text));
                Console.Error.WriteLine(@"The remoting client encountered an error: " + text.Name);

                var okButton = windowAutomationElement.FindFirstChild(
                    new AndCondition(automation.ConditionFactory.ByName("OK"),
                        automation.ConditionFactory.ByControlType(ControlType.Button)));
                windowAutomationElement.SetForeground();
                Console.WriteLine("Closing error dialog");
                Thread.Sleep(500);
                okButton.Click(false);
                Thread.Sleep(500);
                if (parent != null)
                {
                    Console.WriteLine("Closing parent window");
                    parent.Close();
                }

                return true;
            }

            return false;
        }

        private static string ProcessNameFromWindowHandle(IntPtr handle)
        {
            uint processId;
            var _ = User32.GetWindowThreadProcessId(handle, out processId);
            using (var process = Process.GetProcessById((int)processId))
                return process.ProcessName;
        }

        private static bool ClickSignIn(AutomationElement child)
        {
            var controlTypeCondition =
                new PropertyCondition(AutomationObjectIds.ControlTypeProperty, ControlType.Button);
            var textCondition = new PropertyCondition(AutomationObjectIds.NameProperty,
                "Sign in",
                PropertyConditionFlags.IgnoreCase | PropertyConditionFlags.MatchSubstring);
            var condition = new AndCondition(controlTypeCondition, textCondition);
            var result = child.FindFirst(TreeScope.Descendants, condition);
            if (result == null)
            {
                Console.WriteLine("Sign in button is not found");
                return false;
            }
            child.SetForeground();

            Console.WriteLine("Found sign in button, clicking");
            result.AsButton().Click(false);
            return true;
        }

        private static void ClickNext(AutomationElement child)
        {
            var controlTypeCondition =
                new PropertyCondition(AutomationObjectIds.ControlTypeProperty, ControlType.Button);
            var textCondition = new PropertyCondition(AutomationObjectIds.NameProperty,
                "Next",
                PropertyConditionFlags.IgnoreCase | PropertyConditionFlags.MatchSubstring);
            var condition = new AndCondition(controlTypeCondition, textCondition);
            var result = child.FindFirst(TreeScope.Descendants, condition);
            if (result == null)
            {
                Console.WriteLine("Sign in button is not found");
            }
            child.SetForeground();

            Console.WriteLine("Found sign in button, clicking");
            result.AsButton().Click(false);
        }

        private static AutomationElement FindEmailEdit(AutomationElement child)
        {
            var controlTypeCondition = new PropertyCondition(AutomationObjectIds.ControlTypeProperty, ControlType.Edit);
            var textCondition = new PropertyCondition(AutomationObjectIds.NameProperty,
                "your email",
                PropertyConditionFlags.IgnoreCase | PropertyConditionFlags.MatchSubstring);
            var condition = new AndCondition(controlTypeCondition, textCondition);

            AutomationElement result = null;
            var stopwatch = Stopwatch.StartNew();

            while (true)
            {
                Console.WriteLine("Waiting for email edit control");
                if (stopwatch.Elapsed.TotalSeconds > 10)
                {
                    break;
                }

                try
                {
                    result = child.FindFirst(TreeScope.Descendants, condition);
                    if (result != null && result.IsOffscreen == false)
                        break;
                }
                catch
                {
                    // This will happen while the window is moving the password field in view, so we don't care
                }

                Thread.Sleep(500);
            }

            return result;
        }


        private static AutomationElement FindPasswordEdit(AutomationElement child, string userName)
        {
            var controlTypeCondition = new PropertyCondition(AutomationObjectIds.ControlTypeProperty, ControlType.Edit);
            var textCondition = new PropertyCondition(AutomationObjectIds.NameProperty,
                userName,
                PropertyConditionFlags.IgnoreCase | PropertyConditionFlags.MatchSubstring);
            var condition = new AndCondition(controlTypeCondition, textCondition);

            AutomationElement result = null;
            var stopwatch = Stopwatch.StartNew();

            while (true)
            {
                Console.WriteLine("Waiting for password field");
                if (stopwatch.Elapsed.TotalSeconds > 10)
                {
                    break;
                }

                try
                {
                    result = child.FindFirst(TreeScope.Descendants, condition);
                    if (result != null && result.IsOffscreen == false)
                        break;
                }
                catch
                {
                    // This will happen while the window is moving the password field in view, so we don't care
                }

                Thread.Sleep(500);
            }

            return result;
        }

        private static bool ClickUseAnotherAccount(AutomationElement child)
        {
            var controlTypeCondition =
                new PropertyCondition(AutomationObjectIds.ControlTypeProperty, ControlType.Button);
            var textCondition = new PropertyCondition(AutomationObjectIds.NameProperty,
                "Use another account",
                PropertyConditionFlags.IgnoreCase | PropertyConditionFlags.MatchSubstring);
            var condition = new AndCondition(controlTypeCondition, textCondition);
            var result = child.FindFirst(TreeScope.Descendants, condition);
            if (result == null)
            {
                Console.WriteLine("Use another account button is not found");
                return false;
            }

            Console.WriteLine("Found use another account button, clicking");
            child.SetForeground();
            result.AsButton().Click(false);
            return true;
        }

        private static bool IsAuthenticationWindow(TopLevelWindow window)
        {
            if (!window.Class.Equals("ApplicationFrameWindow"))
            {
                return false;
            }
            if (!ProcessNameFromWindowHandle(window.Handle).Equals("explorer"))
            {
                return false;
            }

            Console.WriteLine("Process is explorer");
            return true;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll")]
        static extern uint RealGetWindowClass(IntPtr hwnd, [Out] StringBuilder pszType,
            uint cchType);

        [DllImport("USER32.DLL")]
        public static extern IntPtr GetShellWindow();

        public delegate bool EnumWindowsProc(IntPtr hWnd, int lParam);

        [DllImport("USER32.DLL")]
        public static extern bool EnumWindows(EnumWindowsProc enumFunc, int lParam);

        [DllImport("USER32.DLL")]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        private static TopLevelWindow[] GetTopLevelWindows()
        {
            var shellWindow = GetShellWindow();
            var matchingWindows = new List<TopLevelWindow>();
            var buffer = new StringBuilder(128);

            EnumWindows(delegate (IntPtr hWnd, int lParam)
            {
                if (hWnd == shellWindow)
                {
                    return true;
                }

                if (!IsWindowVisible(hWnd))
                {
                    return true;
                }

                buffer.Clear();
                GetWindowText(hWnd, buffer, 128);
                var title = buffer.ToString();
                buffer.Clear();
                RealGetWindowClass(hWnd, buffer, 128);
                var realClass = buffer.ToString();

                matchingWindows.Add(new TopLevelWindow(hWnd, title, realClass));

                return true;
            },
                0);

            return matchingWindows.ToArray();
        }

        class TopLevelWindow
        {
            public TopLevelWindow(IntPtr handle, string title, string @class)
            {
                Handle = handle;
                Title = title;
                Class = @class;
            }

            public IntPtr Handle { get; private set; }
            public string Title { get; private set; }
            public string Class { get; private set; }
        }

    }
}
