﻿window.onerror = function (msg, source, line) {
    LE__Log(`Browser 'window' error: ${msg} on line ${line} in source ${source}`);
}

if (window.chrome.webview) {    
    window.chrome.webview.hostObjects.options.log = LE__Log;
    LE__Log("Redirected log");
}

function LE__Log(command) {
    if (window.chrome.webview) {
        window.chrome.webview.postMessage(command);
    } else {
        console.log(command);
    }
}

var __completedRequests = [];

function LE__GetCookieValue(name) {
    const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
    if (match) return match[2];
    return null;
}

function LE__ApiCallReturned(url, statusCode, contents) {
    if (statusCode === "OK") {
        __completedRequests.push(url);
    }
    window.chrome.webview.postMessage(`##APICALL,${url},${statusCode},${contents}`);
}

function LE__StartConnector(filename, fileContents) {
    LE__Log("##CONNECT," + filename + "," + fileContents);
}

function LE__DoesValueMatchWildcard(value, wildcard) {
    const escapeRegex = (v) => v.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    return new RegExp(`^${wildcard.split("*").map(escapeRegex).join(".*")}$`).test(value);
}

function LE__HasApiRequestCompleted(urlWildcard) {
    for (var url of __completedRequests) {
        if (LE__DoesValueMatchWildcard(url, urlWildcard))
            return true;
    }
    return false;
}

function LE__GetOnlyTextOfElement(element) {
    var child = element.firstChild;
    var texts = [];

    while (child) {
        if (child.nodeType == 3) {
            texts.push(child.data);
        }
        child = child.nextSibling;
    }

    var text = texts.join("");
    return text;
}

function LE__FindElementWithClassAndText(tag, className, text) {
    LE__Log("Looking for element " + tag + ", class " + className + " with text '" + text + "'");
    var divs = document.querySelectorAll(tag);
    var searchText = text;
    for (const div of divs) {
        if (div.className.includes(className) && LE__GetOnlyTextOfElement(div).includes(searchText)) {
            LE__Log("Found " + div.textContent);
            return div;
        }
    }
    return null;
}

function LE__FindElementWithText(tag, text) {
    LE__Log("Looking for element " + tag + " with text '" + text + "'");
    var divs = document.querySelectorAll(tag);
    var searchText = text;
    for (const div of divs) {
        if (LE__GetOnlyTextOfElement(div).includes(searchText)) {
            LE__Log("Found " + div.textContent);
            return div;
        }
    }
    return null;
}

function LE__Delay(milliseconds) {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve();
        }, milliseconds);
    });
}

async function LE__WaitForElement(getElement) {
    var element = getElement();
    while (!element) {
        LE__Log("Waiting until 'getElement' returns something");
        await LE__Delay(500);
        element = getElement();
    }
    return element;
}

async function LE__WaitForElementMatch(tagName, elementMatches) {
    while (true) {
        LE__Log("Waiting for matching elements with tag(s): " + tagName);
        const candidates = document.querySelectorAll(tagName);
        for (const candidate of candidates) {
            if (elementMatches(candidate))
                return candidate;
        }

        await LE__Delay(500);
    }
}

function LE__SetNetworkRequestCallback() {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function () {
        //debugger;
        this.addEventListener("load", function () {
            requestEnded.bind(this)();
        });
        this.addEventListener("error", function () {
            LE__Log("Failed");
            requestFailed.bind(this)();
        });
        origOpen.apply(this, arguments);
    };
}

// 'this' is XMLHttpRequest
function requestEnded() {
    if (this.responseURL.endsWith('List')) {
        //debugger;
    }
    const text = (this.responseType === "" ||
        this.responseType === "text" ||
        this.responseType === "json") ? this.responseText : "";
    LE__ApiCallReturned(this.responseURL, this.statusText, text);
}

// 'this' is XMLHttpRequest
function requestFailed() {
    const text = (this.responseType.length === 0 ||
        this.responseType === "text" ||
        this.responseType === "json") ? this.responseText : "";

    LE__ApiCallReturned(this.responseURL, this.statusText, text);
}

function LE__IsHidden(element) {
    if (element.offsetParent === null) {
        return true;
    }

    const style = window.getComputedStyle(element);
    return (style.display === 'none');
}

function LE__LogElements(list, tagName) {
    const elements = document.getElementsByTagName(tagName);
    var element;
    for (element of elements) {
        if (!LE__IsHidden(element)) {
            list.push(element.outerHTML);
        }
    }
}

function LE__LogInterestingElements() {
    const list = [];
    LE__LogElements(list, 'input');
    LE__LogElements(list, 'button');
    LE__LogElements(list, 'a');
    const fullText = list.join('\n');
    LE__Log(`##ELEMENTS,${fullText}`);
}


// Runs a PowerShell script and returns the result of the script
// The scriptArgumentsAsdString MUST use named arguments
// The PowerShell script caller will add an argument called resultFilePath to the back of the list
// If you fill in the password field, it will be sent through std-in to the script
async function LE__RunPowerShellScript(scriptName, scriptArgumentsString, password) {
    LE__Log(`Running PowerShell ${scriptName} with arguments '${scriptArgumentsString}'`);
    const token = await window.chrome.webview.hostObjects.dotnet.RunPowerShellScript(scriptName, scriptArgumentsString, password);
    LE__Log("Running " + scriptName + " done");
    return token;
}

async function LE__OnDownloadRunWithEngine(scriptName, sendPassword) {
    LE__Log(`On download, we will run the Engine script ${scriptName}`);
    await window.chrome.webview.hostObjects.dotnet.OnDownloadRunWithEngine(scriptName, sendPassword);
}

async function LE__SetConnectParameters(parametersString, password) {
    await window.chrome.webview.hostObjects.dotnet.SetConnectParameters(parametersString, password);
}

async function LE__OnDownloadRunFile() {
    await window.chrome.webview.hostObjects.dotnet.OnDownloadRunFile();
}

async function LE__LoadCookies(cookieFilePath) {
    await window.chrome.webview.hostObjects.dotnet.LoadCookies(cookieFilePath);
}

LE__SetNetworkRequestCallback();

LE__Log("Bootstrapper loaded")
