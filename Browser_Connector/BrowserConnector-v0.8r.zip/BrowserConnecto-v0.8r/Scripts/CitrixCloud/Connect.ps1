﻿
param([String]$connectionFile="") 

Write-Host("Starting ICA file $connectionFile");

Start-Process($connectionFile)