﻿//Path=/*oauth*

async function Run() {
    LE__Log("Processing Login Form");
    var emailInput = await LE__WaitForElement(GetEmailInputField);

    SetValue(emailInput, "${User}");

    var submitButton = await LE__WaitForElement(GetSubmitButton);
    submitButton.click();

    var passwordInput = await LE__WaitForElement(GetPasswordInputField);

    SetValue(passwordInput, "${Password}");

    submitButton = await LE__WaitForElement(GetSubmitButton);
    submitButton.click();
}

Run();

// Helper functions
function GetEmailInputField() {
    LE__Log("Waiting for email input");
    var elements = Array.from(document.getElementsByTagName("input")).filter(e => !LE__IsHidden(e) && e.type == 'email');
    return elements.length > 0 ? elements[0] : null;
}

function GetPasswordInputField() {
    LE__Log("Waiting for password input");
    var elements = Array.from(document.getElementsByTagName("input")).filter(e => !LE__IsHidden(e) && e.type == 'password');
    return elements.length > 0 ? elements[0] : null;
}

function GetSubmitButton() {
    LE__Log("Waiting for submit button");
    var elements = Array.from(document.getElementsByTagName("input")).filter(e => !LE__IsHidden(e) && e.type == 'submit');
    return elements.length > 0 ? elements[0] : null;
}

function SetValue(element, text) {
    element.value = text;

    // Some SPA technologies do not detect the change if done by setting the value
    // so we explicitely send the 'change' event
    var event = new window.Event('change', { bubbles: true });
    element.dispatchEvent(event);

    LE__Log(`Filled input field '${element.type}'`);
}

