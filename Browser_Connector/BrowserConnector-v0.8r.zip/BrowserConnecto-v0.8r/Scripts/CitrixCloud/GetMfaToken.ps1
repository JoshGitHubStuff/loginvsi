﻿#These parameters need to stay this way
param(
	[String]$url="",          #Host url where the browser connector is working on
	[String]$user="",         #User specified with or without domain
	[String]$domain="",	      #Domain will be set to 'N__A' if no domain was specified (in that case it will be part of the $user parameter)
	[String]$resource="",     #Selected target resource
	[String]$tokenFilePath="" #In this file, the connector expects the token to be written after completion
) 

# https://github.com/ecspresso/TOTPPowerShellModule

Write-Host "'$url' is asking for an MFA token"

if ($domain -eq "N__A") {
	Write-Host("Get MFA token for user '$user' and resource $resource");
}
else {
	Write-Host("Get MFA token for user '$user@domain' and resource $resource");
}

Write-Host "Writing file $tokenFilePath"

Set-Content $tokenFilePath 'abcdef123456'