﻿//Path=/*/login

async function Run() {
    var element = await LE__WaitForElement(function () {
        return document.getElementById("idBtn_Back");
    });
    element.click();
}

Run();