﻿//Path=/Citrix/StoreWeb*

//${Resource}
async function Run() {
    LE__Log("Processing StoreWeb page for resource '${Resource}'");
    if (!localStorage.getItem('clientDetectionKey')) {
        LE__Log("Setting client detection key and reloading page");
        localStorage.setItem('clientDetectionKey', 'native');
        location.reload();
        return;
    }

    // The page reloads after logging in to the same location,
    // causing this script to run again. 
    // So we have to detect if we logged in to know
    // what we are supposed to do
    if (await HasLoggedIn()) {
        await SelectResource();
    } else {
        await Login();
    }
}

async function HasLoggedIn() {
    while (true) {
        LE__Log("Checking login status");
        await LE__Delay(1000);
        var element = document.getElementById('username');
        if (element) {
            LE__Log("We did not log in yet");
            return false;
        }
        for (const el of document.getElementsByTagName('span')) {
            if (el.innerText === "Search Workspace") {
               LE__Log("We did log in already");
               return true;
            }
        }
    }
}

async function SelectResource() {
    LE__Log("Selecting resource");
    while (!LE__HasApiRequestCompleted("*StoreWeb/Resources/Lis*")) {
        LE__Log("Waiting for resources retrieval to complete");
        await LE__Delay(500);
    }

    LE__OnDownloadRunFile();

    var resourceAvailable = true;
    var element = await LE__WaitForElementMatch("a, div", function(el) {
        if (el.tagName == "a") {
            resourceAvailable = false;
            return el.href.endsWith("/desktops");
        } else {
            resourceAvailable = true;            
            return el.title && (el.title.toLowerCase().includes('${Resource}'.toLowerCase()));
        }
    });
    LE__Log("Resource is available directly");
    if (resourceAvailable) {
        LE__Log("Resource is available directly");
        element.click();
        return;
    }
    LE__Log("Resource is not available, we need to click the 'desktops' link");
    element.click();

    element = await LE__WaitForElementMatch("span", function (el) {
        return LE__GetOnlyTextOfElement(el).includes("All Desktops");
    });
    element.click();

    LE__Log("Clicked 'all desktops'");
    element = await LE__WaitForElementMatch("div", function (el) {
        return el.title.toLowerCase().includes('${Resource}'.toLowerCase());
    });

    element.click();
}

async function Login() {
    LE__Log("Logging in");
    const loginElement = await LE__WaitForElement(function () {
        return document.getElementById('username');
    });
    loginElement.value = '${User}';
    document.getElementById('password').value = '${Password}';

    document.getElementById('loginBtn').click();
    LE__Log("Clicked login button");
}

Run();


