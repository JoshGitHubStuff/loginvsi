﻿//Path=/logon/LogonPoint/tmindex.html
LE__Log("Processing Login Form");

async function Run() {
    const loginElement = await LE__WaitForElement(function() {
         return document.getElementById('login');
    });
    loginElement.value = '${User}';
    document.getElementById('passwd').value = '${Password}';
    const domainSelector = document.getElementById('domain');
    if (domainSelector) {
        domainSelector.value = '${Domain}'.toUpperCase();
    }

    const loginButtonIds = ['Logon', 'loginBtn'];
    var loginButton = null;
    for (const buttonId of loginButtonIds) {
        loginButton = document.getElementById(buttonId);
        if (loginButton) {
            break;
        }
    }
    if (loginButton) {
        loginButton.click();
        LE__Log("Clicked login button");
    } else {
        LE__Log("Login button not found");
    }
}

Run();


