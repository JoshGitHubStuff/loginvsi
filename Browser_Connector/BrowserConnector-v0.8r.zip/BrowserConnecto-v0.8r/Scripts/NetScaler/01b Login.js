﻿//Path=/vpn/index.html
LE__Log("Processing Login Form");

async function Run() {
    const loginElement = await LE__WaitForElement(function() {
         return document.getElementById('Enter user name');
    });
    loginElement.value = '${User}';
    document.getElementById('passwd').value = '${Password}';
    const domainSelector = document.getElementById('domain');
    if (domainSelector) {
        domainSelector.value = '${Domain}';
    }
    document.getElementById('Log_On').click();
    LE__Log("Clicked login button");
}
Run();

