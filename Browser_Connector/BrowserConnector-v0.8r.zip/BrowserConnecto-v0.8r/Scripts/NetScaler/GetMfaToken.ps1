﻿#These parameters need to stay this way
param(
	[String]$resultFilePath="" #In this file. This MUST be the last argument in the list.
) 

Write-Host("Running script GetMfaToken");

Write-Host "Writing file $resultFilePath"

Set-Content $resultFilePath 'abcdef123456'