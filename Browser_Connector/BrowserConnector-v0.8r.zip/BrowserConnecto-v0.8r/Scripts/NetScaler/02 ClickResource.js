﻿//Path=/*Web?

async function Run() {
    while (!LE__HasApiRequestCompleted("*GetUserName*")) {
        LE__Log("Waiting for user name retrieval to complete");
        await LE__Delay(500);
    }
    LE__Log("GetUsername API call completed");

    var desktopsButton = document.getElementById('desktopsBtn');
    while (!desktopsButton) {
        await LE__Delay(500);
        desktopsButton = document.getElementById('desktopsBtn');
    }
    LE__Log("Desktops button available. Executing click.");

    desktopsButton.click();

    var element = LE__FindElementWithText("p", "${Resource}");

    while (!element) {
         await LE__Delay(500);
         element = LE__FindElementWithText("p", "${Resource}");
    }
    LE__Log("${Resource} link available. Executing click()");

    LE__OnDownloadRunFile();
    element.parentElement.previousSibling.click();
//    LE__Log("Clicked resource. Download is expected to begin.");
}

if (LE__GetCookieValue("CtxsClientDetectionDone")) {
    Run();
} else {
    // We need client detection cookies to skip the client detection user interaction
    LE__LoadCookies("ClientCookies.json");
    location.reload();
}

