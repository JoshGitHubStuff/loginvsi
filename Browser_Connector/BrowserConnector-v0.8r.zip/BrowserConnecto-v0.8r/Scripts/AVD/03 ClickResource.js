﻿//Path=/arm/webclient/index.html

async function Run() {
    if (window.history.length <= 1 && IsLocalStorageFilled()) {
        LE__Log('Local storage detected from previous session, resetting.');
        localStorage.clear();
        location.reload();
    } else {
        var settingsButton = await LE__WaitForElement(GetSettingsButton);
        settingsButton.click();

        var nativeClientButton = await LE__WaitForElement(GetNativeClientSelector);
        nativeClientButton.click();

        //LE__SetConnectParameters("-user ${User} -resource ${Resource}","${Password}");
        LE__OnDownloadRunWithEngine("Connect", true);
        var resourceLink = await LE__WaitForElement(GetDownloadButton);
        resourceLink.click();

        LE__Log("Waiting a while before clearing local storage");
        await LE__Delay(1000);

        localStorage.clear();
        LE__Log("Local storage has been cleared");

    }
}
Run();

function IsLocalStorageFilled() {
    try {
        return localStorage.length > 0;
    } catch (error) {
        console.warn(`Error while checking local storage: ${error}`);
        return false;
    }

}

// Helper functions
function GetSettingsButton() {
    LE__Log("Waiting for settings button");
    var elements = Array.from(document.getElementsByTagName("a")).filter(e => !LE__IsHidden(e) && e.title == "Settings");
    return elements.length > 0 ? elements[0] : null;
}

//<input type="radio" ng-model="resourceLaunchMethod" value="nativeclient"
function GetNativeClientSelector() {
    LE__Log("Waiting for native client radio button");
    var elements = Array.from(document.getElementsByTagName("input")).filter(e => !LE__IsHidden(e) && e.type == "radio" && e.value == "nativeclient");
    return elements.length > 0 ? elements[0] : null;
}


//<div class="rdhtml5-applabel">MP-WVD-EU- 2-HOSTP...</div>
function GetDownloadButton() {
    LE__Log("Waiting for download button: ${Resource}");
    return LE__WaitForElementMatch("div", function(el) {
        return el.title === "${Resource}";
    });
}