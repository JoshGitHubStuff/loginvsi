using System;
using System.IO;
using System.Linq;
using System.Diagnostics;
using LoginPI.Engine.ScriptBase;
using LoginPI.Engine.ScriptBase.Components;
using Interop.UIAutomationClient;

public class Connector : ScriptBase
{
    bool _loginPassed = false;
    bool _wincredsPassed = false;
    string userName;
    string password;

    void Execute()
    {
        Log("Reading password from standard in");
        password = string.IsNullOrWhiteSpace(ApplicationPassword) ? Console.ReadLine() : ApplicationPassword;        
        userName = ApplicationUser;
        Log($"Starting '{CommandLine}' for user '{userName}'");
        var rdpcFileLines = File.ReadAllLines(CommandLine);
        string resourceName = null;
        foreach (var line in rdpcFileLines)
        {
            if (line.StartsWith("remotedesktopname"))
            {
                resourceName = line.Split(':')[2];
            }
        }
        if (resourceName == null)
        {
            ABORT("The resource name could not be parsed from the connection file");
            return;
        }
        Log($"Detected resource name '{resourceName}'");

        var errorWindows = FindWindows(processName: "msrdc", className: "*#32770", timeout: 1);
        foreach (var errorWindow in errorWindows)
        {
            Log("Closing error window from previous connection.");
            errorWindow.FindControl(className: "Button:CCPushButton", title: "OK", timeout: 1, continueOnError: true)?.Click();
        }

        var openConnectorWindows = FindWindows(processName: "msrdc", title: resourceName, timeout: 1).Select(w => w.NativeWindowHandle).ToArray();
        Log($"Before starting the connection we had {openConnectorWindows.Length} other open connections");
        
        // We use the native process.Start to avoid the engine from waiting for the msrdc process
        var process = Process.Start(CommandLine);
        Log($"Started {process.ProcessName}");
        var timeout = System.Diagnostics.Stopwatch.StartNew();

        while (timeout.Elapsed.TotalSeconds < 60)
        {
            Wait(3);
            if (!_loginPassed && ProcessAuthenticationWindow())
                continue;

            if (!_wincredsPassed && ProcessWinCredWindow())
                continue;

            var newConnectorWindows = FindWindows(processName: "msrdc", title: resourceName, timeout: 1).ToArray();
            var newConnectorWindow = newConnectorWindows.Select(window => window.NativeWindowHandle).FirstOrDefault(handle => !openConnectorWindows.Contains(handle));
            if (newConnectorWindow != IntPtr.Zero)
            {
                Log("Found new connection window!");
                File.Delete(CommandLine);
                return;
            }

            errorWindows = FindWindows(processName: "msrdc", className: "*#32770", timeout: 1);
            if (errorWindows.Length > 0)
            {
                Log($"Found {errorWindows.Length} connection error windows.");
                var errorWindow = errorWindows[0];
                var text = errorWindow.FindControl(className: "Text:Element", timeout: 2);
                var message = text.GetTitle();
                errorWindow.FindControl(className: "Button:CCPushButton", title: "OK", timeout: 1, continueOnError: true)?.Click();
                File.Delete(CommandLine);
                ABORT(message);
            }
        }
    }

    private bool ProcessAuthenticationWindow()
    {
        var authenticationWindows = FindWindows(className: "*ApplicationFrameWindow*", timeout: 1); //processName: "explorer"
        Log($"Found {authenticationWindows.Length} possible authentication windows");
        foreach (var window in authenticationWindows)
        {
            if (!ClickUseAnotherAccount(window))
            {
                Log("This is not the candidate you are looking for");
                continue;
            }

            Log("Found authentication window");
            window.SwitchTopMostWindow(true);
            var emailControl = window.FindControl(className: "Edit", title: "*email*", continueOnError: true, timeout: 5);
            if (emailControl is null)
            {
                Log("User name was not found");
                window.Close();
                ABORT("Authentication window does not have a matching user name input");
                // ABORT will end the script here,
                // but we need the next statement to make the compiler shut up
                return false;
            }
            if (_loginPassed)
                ABORT("The authentication window appeared again. Probably the login failed.");

            var emailValue = emailControl.NativeAutomationElement.GetCurrentPattern(UIA_PatternIds.UIA_ValuePatternId) as IUIAutomationValuePattern;
            emailValue.SetValue(userName);
            Wait(0.2);            
            window.FindControl(className:"*Button", title: "Next").Click();
            // We don't want to be kept in an infinite loop

            _loginPassed = true;

            IWindow errorMessage;
            var passwordControl = window.FindControl(className: "Edit", title: "*password*", continueOnError: true, timeout: 5);
            if (passwordControl is null)
            {
                Log("Password was not found");

                errorMessage = window.FindControl(className: "Text", title: "*an account with that username*");
                window.Close();
                if (errorMessage is null)
                {
                    ABORT("Credentials window does not have a matching password input");
                }
                else
                {
                    ABORT(errorMessage.GetTitle());
                }
                // ABORT will end the script here,
                // but we need the next statement to make the compiler shut up
                return false;
            }
            var passwordValue = passwordControl.NativeAutomationElement.GetCurrentPattern(UIA_PatternIds.UIA_ValuePatternId) as IUIAutomationValuePattern;
            passwordValue.SetValue(password);
            Wait(0.2);
            window.FindControl(className:"*Button", title: "Sign*").Click();

            errorMessage = window.FindControl(className: "Text", title: "*incorrect*", continueOnError: true, timeout: 3);
            if (errorMessage != null)
            {
                ABORT(errorMessage.GetTitle());
            }

            _loginPassed = true;
            return true;
        }

        return false;
    }

    private bool ClickUseAnotherAccount(IWindow window)
    {
        var useAnotherAccountWindow = window.FindControl(title: "Use another account", timeout: 1, continueOnError: true);
        if (useAnotherAccountWindow != null)
        {
            useAnotherAccountWindow.SwitchTopMostWindow(true);
            useAnotherAccountWindow.Click();
            return true;
        }

        return (window.FindControl(className: "Edit", title: "*email*", timeout: 1, continueOnError: true) != null);
    }

    private bool ProcessWinCredWindow()
    {
        var credsWindow = FindWindow(className: "*Credential*", processName: "CredentialUIBroker", continueOnError: true, timeout: 3);
        if (credsWindow is null)
            return false;

        if (_wincredsPassed)
            ABORT("The Windows credentials appeared again. Probably its process failed.");

        Log("Found credentials windows");

        credsWindow.SwitchTopMostWindow(true);
        credsWindow.Focus();
        var passwordBox = credsWindow.FindControl(className: "*PasswordBox*", title: "Password", continueOnError: true, timeout: 3);
        if (passwordBox is null)
        {
            Log("Password was not found");
            ABORT("Credentials window does not have a matching password input");
            // ABORT will end the script here,
            // but we need the next statement to make the compiler shut up
            return false;
        }
        Log("Typing password");
        var passwordValue = passwordBox.NativeAutomationElement.GetCurrentPattern(UIA_PatternIds.UIA_ValuePatternId) as IUIAutomationValuePattern;
        passwordValue.SetValue(password);

        var stayLoggedInCheckBox = credsWindow.FindControl(className: "*CheckBox*", continueOnError: true, timeout: 3);
        if (stayLoggedInCheckBox is null)
        {
            Log("Stay checked in checkbox was not found, ignoring");
            return false;
        }
        else
        {        
            var togglePattern = stayLoggedInCheckBox.NativeAutomationElement.GetCurrentPattern(UIA_PatternIds.UIA_TogglePatternId) as IUIAutomationTogglePattern;
            if (togglePattern.CurrentToggleState == ToggleState.ToggleState_Off)
                togglePattern.Toggle();
        }

        var loginButton = credsWindow.FindControl(className: "Button:Button", title: "OK", continueOnError: true, timeout: 3);
        if (loginButton is null)
        {
            Log("Login button was not found");
            ABORT("Credentials window does not have a matching user name input");
            // ABORT will end the script here,
            // but we need the next statement to make the compiler shut up
            return false;
        }
        loginButton.Click();

        _wincredsPassed = true;
        return true;
    }
}
