The BrowserConnector.zip file contains the binaries of the connector.
Copy this to a folder where the launcher can call it as a custom connector.
Check out https://loginvsi.atlassian.net/wiki/spaces/LE/pages/2136866964/NetScaler+connector+prototype
for more information.

Parameters:
 Url={Url}
 TimeoutInSeconds={Text}
 User={Text}
 Domain={Text}
 Password={Text}
 Resource={Text}
 Script={Text}
 -DownloadOnly
 -Debugger
 -LogApiCalls
 -LogApiContent

If you don't pass the password argument, it will be read from stdin

Prereqs: 
https://dotnet.microsoft.com/en-us/download/dotnet-framework/net48
https://developer.microsoft.com/en-us/microsoft-edge/webview2/


from v0.7:
The AVD connector uses the Login Enterprise stand alone engine for the client automation.
It counts on script editor to be present in the same folder as the browser connector

before v0.7:
The AVD connector uses the FlaUI automation NuGet package:
see: https://github.com/FlaUI/FlaUI
